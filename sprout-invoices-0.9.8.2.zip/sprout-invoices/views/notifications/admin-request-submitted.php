---------------------------------------------
Lead Generated Requested
---------------------------------------------

[lead_entries]

Estimate Created: [estimate_id]
[estimate_edit_url]
Client: [client_name]
[client_edit_url]
Amount: [estimate_total]

Go get 'em

---------------------------------------------
