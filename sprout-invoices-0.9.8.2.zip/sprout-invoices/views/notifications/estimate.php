---------------------------------------------
Estimate Summary
---------------------------------------------

[name]

[estimate_subject]

[admin_note]

Estimate ID: [estimate_id]
Estimate date: [estimate_issue_date]
Client: [client_name]
P.O. Number: [estimate_po_number]
Amount: [estimate_total]

[line_item_table]

You can view the estimate here:
[estimate_url]

Thank you!
---------------------------------------------
