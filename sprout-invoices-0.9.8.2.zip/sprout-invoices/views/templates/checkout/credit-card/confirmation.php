<?php 
// Variables available.
// prp($payment_id);
// prp($checkout);