<?php 

// FUTURE 
// Allow for client comments on estimates and invoices. Could use a new post_type or wp_comments (comment_type https://core.trac.wordpress.org/ticket/12668).